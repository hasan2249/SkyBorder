<?php

namespace App\Models;

class BlogMapCategory extends BaseModel
{
    public $timestamps = false;
}
